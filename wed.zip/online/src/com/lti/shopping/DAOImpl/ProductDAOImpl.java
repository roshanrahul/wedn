package com.lti.shopping.DAOImpl;

import java.util.List;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.shopping.DAO.ProductDAO;
import com.lti.shopping.model.Product;
import com.lti.shopping.model.Seller;


@Repository("ProductDAO")
public class ProductDAOImpl implements ProductDAO {
	
	private static final Logger logger = 			
			LoggerFactory.getLogger(ProductDAOImpl.class);
	
 
	Transaction tx;
	@Autowired
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
			  
	
	

	@Override
	public Product get(int productId) {
		 
		return null;
	}

	
	@Override
	public List<Product> list() {
		Session session =this.sessionFactory.getCurrentSession(); 
		  List<Product> productList =session.createQuery("from Product").list(); 
		  for ( Product p : productList) {
			  logger.info("Product List::" + p); 
		  	} 
		  return  productList; 
	}

	
	@Override
	public void add(Product product) {
		Session session = this.sessionFactory.openSession();
		tx =  session.beginTransaction();
		session.save(product);
		tx.commit();
		session.close();
		logger.info("Product details saved successfully, User Details="+product);

	}

	@Override
	public void update(Product product) {
		 
		Session session = 
				this.sessionFactory
				.getCurrentSession();
		session.update(product);
		logger.info("Person updated successfully, "
				+ "Person Details=" + product);

	}

	@Override
	public void delete(int product) {
		Session session = this.sessionFactory.getCurrentSession();
		Product p = 
		(Product) session.load(Product.class, new Integer(product));
		if (null != p) {
			session.delete(p);
		}else {
			logger.error
			("Person NOT deleted, with person Id=" +product);
		}
		logger.info("Person deleted successfully, person details=" + p);
	}


		 
	}


